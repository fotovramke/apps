CheckBox account
============================

Integrates CheckBox with odoo accounting

This module is developed by the `KitWorks <https://kitworks.systems/>`__.

