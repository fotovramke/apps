CheckBox
============================

You can register receipts from invoices

This module is developed by the `KitWorks <https://kitworks.systems/>`__.

