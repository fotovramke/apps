CheckBox
============================

Implementation of receipt registration through CheckBox services

This module is developed by the `KitWorks <https://kitworks.systems/>`__.

