CheckBox
============================

Integrates CheckBox with odoo product.product

This module is developed by the `KitWorks <https://kitworks.systems/>`__.

