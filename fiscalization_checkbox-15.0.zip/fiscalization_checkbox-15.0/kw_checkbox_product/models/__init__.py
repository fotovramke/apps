
from . import (
    product_template,
    product,
)
