from . import (
    cash_register,
    checkbox_category,
    pos_config,
    shift,
    pos_session,
    pos_order,
    pos_payment_method,
)
